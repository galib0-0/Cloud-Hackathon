import { useState } from "react";
import { supabase } from "./supabaseClient";

export default function Login({ onLogin }) {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [isSignUp, setIsSignUp] = useState(false);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const [successMsg, setSuccessMsg] = useState("");

  const handleAuth = async () => {
    setError("");
    setSuccessMsg("");

    if (!email || !password) {
      setError("Please enter your email and password.");
      return;
    }
    if (password.length < 6) {
      setError("Password must be at least 6 characters.");
      return;
    }

    setLoading(true);
    try {
      const { data, error } = isSignUp
        ? await supabase.auth.signUp({ email, password })
        : await supabase.auth.signInWithPassword({ email, password });

      if (error) throw error;

      if (isSignUp && !data.session) {
        setSuccessMsg("Account created! Check your email to confirm, then log in.");
      } else if (data.user) {
        onLogin(data.user);
      }
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleKeyDown = (e) => {
    if (e.key === "Enter") handleAuth();
  };

  return (
    <div className="login-wrapper">
      <div className="login-card">
        {/* Logo / Header */}
        <div className="login-header">
          <div className="logo-icon">⚡</div>
          <h1 className="app-title">NexChat</h1>
          <p className="app-subtitle">Real-time. Serverless. Free.</p>
        </div>

        {/* Toggle */}
        <div className="tab-toggle">
          <button
            className={`tab-btn ${!isSignUp ? "active" : ""}`}
            onClick={() => { setIsSignUp(false); setError(""); setSuccessMsg(""); }}
          >
            Login
          </button>
          <button
            className={`tab-btn ${isSignUp ? "active" : ""}`}
            onClick={() => { setIsSignUp(true); setError(""); setSuccessMsg(""); }}
          >
            Sign Up
          </button>
        </div>

        {/* Form */}
        <div className="form-group">
          <label className="form-label">Email</label>
          <input
            className="form-input"
            type="email"
            placeholder="you@example.com"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            onKeyDown={handleKeyDown}
            autoComplete="email"
          />
        </div>

        <div className="form-group">
          <label className="form-label">Password</label>
          <input
            className="form-input"
            type="password"
            placeholder="••••••••"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            onKeyDown={handleKeyDown}
            autoComplete={isSignUp ? "new-password" : "current-password"}
          />
        </div>

        {error && <div className="alert alert-error">⚠ {error}</div>}
        {successMsg && <div className="alert alert-success">✓ {successMsg}</div>}

        <button
          className="btn-primary"
          onClick={handleAuth}
          disabled={loading}
        >
          {loading ? "Please wait..." : isSignUp ? "Create Account" : "Login"}
        </button>

        <p className="toggle-link">
          {isSignUp ? "Already have an account? " : "New here? "}
          <span onClick={() => { setIsSignUp(!isSignUp); setError(""); setSuccessMsg(""); }}>
            {isSignUp ? "Log in" : "Sign up free"}
          </span>
        </p>
      </div>
    </div>
  );
}
