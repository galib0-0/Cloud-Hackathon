import { useEffect, useState, useRef, useCallback } from "react";
import { io } from "socket.io-client";
import { supabase } from "./supabaseClient";

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL || "http://localhost:4000";

const DEFAULT_ROOMS = ["general", "tech", "random", "announcements"];

export default function Chat({ user, onLogout }) {
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState("");
  const [roomId, setRoomId] = useState("general");
  const [onlineUsers, setOnlineUsers] = useState(new Set());
  const [typingUsers, setTypingUsers] = useState([]);
  const [connected, setConnected] = useState(false);
  const [loadingHistory, setLoadingHistory] = useState(true);

  const socketRef = useRef(null);
  const bottomRef = useRef(null);
  const typingTimeoutRef = useRef(null);

  // ── Load Message History ────────────────────────────────────────────────────
  const loadHistory = useCallback(async (room) => {
    setLoadingHistory(true);
    try {
      const res = await fetch(`${BACKEND_URL}/messages/${room}`);
      const data = await res.json();
      setMessages(Array.isArray(data) ? data : []);
    } catch {
      setMessages([]);
    } finally {
      setLoadingHistory(false);
    }
  }, []);

  // ── Socket Setup ────────────────────────────────────────────────────────────
  useEffect(() => {
    const socket = io(BACKEND_URL, { transports: ["websocket", "polling"] });
    socketRef.current = socket;

    socket.on("connect", () => {
      setConnected(true);
      socket.emit("join_room", {
        roomId,
        userId: user.id,
        email: user.email,
      });
    });

    socket.on("disconnect", () => setConnected(false));

    socket.on("receive_message", (msg) => {
      setMessages((prev) => [...prev, msg]);
    });

    socket.on("user_joined", ({ email }) => {
      setOnlineUsers((prev) => new Set([...prev, email]));
      setMessages((prev) => [
        ...prev,
        { system: true, message_text: `${email} joined`, created_at: new Date().toISOString() },
      ]);
    });

    socket.on("user_left", ({ email }) => {
      setOnlineUsers((prev) => {
        const next = new Set(prev);
        next.delete(email);
        return next;
      });
      setMessages((prev) => [
        ...prev,
        { system: true, message_text: `${email} left`, created_at: new Date().toISOString() },
      ]);
    });

    socket.on("typing", ({ email, isTyping }) => {
      setTypingUsers((prev) =>
        isTyping ? [...new Set([...prev, email])] : prev.filter((e) => e !== email)
      );
    });

    return () => socket.disconnect();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // ── Room Switch ─────────────────────────────────────────────────────────────
  useEffect(() => {
    setMessages([]);
    setTypingUsers([]);
    loadHistory(roomId);

    if (socketRef.current?.connected) {
      socketRef.current.emit("join_room", {
        roomId,
        userId: user.id,
        email: user.email,
      });
    }
  }, [roomId, loadHistory, user]);

  // ── Auto Scroll ─────────────────────────────────────────────────────────────
  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  // ── Send Message ────────────────────────────────────────────────────────────
  const sendMessage = () => {
    if (!input.trim() || !socketRef.current) return;

    socketRef.current.emit("send_message", {
      roomId,
      userId: user.id,
      email: user.email,
      messageText: input.trim(),
    });

    // Stop typing indicator
    socketRef.current.emit("typing", { roomId, email: user.email, isTyping: false });
    setInput("");
  };

  // ── Typing Indicator ────────────────────────────────────────────────────────
  const handleInputChange = (e) => {
    setInput(e.target.value);
    if (!socketRef.current) return;

    socketRef.current.emit("typing", { roomId, email: user.email, isTyping: true });

    clearTimeout(typingTimeoutRef.current);
    typingTimeoutRef.current = setTimeout(() => {
      socketRef.current?.emit("typing", { roomId, email: user.email, isTyping: false });
    }, 1500);
  };

  // ── Logout ──────────────────────────────────────────────────────────────────
  const handleLogout = async () => {
    await supabase.auth.signOut();
    onLogout();
  };

  // ── Format Time ─────────────────────────────────────────────────────────────
  const formatTime = (iso) => {
    const d = new Date(iso);
    return d.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
  };

  const getInitial = (email) => email?.[0]?.toUpperCase() || "?";
  const getColor = (email) => {
    const colors = ["#6366f1","#ec4899","#f59e0b","#10b981","#3b82f6","#ef4444","#8b5cf6"];
    let hash = 0;
    for (let c of email) hash = c.charCodeAt(0) + ((hash << 5) - hash);
    return colors[Math.abs(hash) % colors.length];
  };

  return (
    <div className="chat-layout">
      {/* ── Sidebar ── */}
      <aside className="sidebar">
        <div className="sidebar-top">
          <div className="brand">⚡ NexChat</div>
          <div className="user-badge">
            <div className="avatar" style={{ background: getColor(user.email) }}>
              {getInitial(user.email)}
            </div>
            <span className="user-email">{user.email}</span>
          </div>
        </div>

        <div className="rooms-section">
          <p className="section-label">ROOMS</p>
          {DEFAULT_ROOMS.map((r) => (
            <button
              key={r}
              className={`room-btn ${roomId === r ? "active" : ""}`}
              onClick={() => setRoomId(r)}
            >
              <span className="room-hash">#</span> {r}
            </button>
          ))}
        </div>

        <button className="logout-btn" onClick={handleLogout}>
          ↩ Logout
        </button>
      </aside>

      {/* ── Main Chat ── */}
      <main className="chat-main">
        {/* Header */}
        <header className="chat-header">
          <div className="chat-header-left">
            <h2 className="room-title"># {roomId}</h2>
            <span className={`status-dot ${connected ? "online" : "offline"}`} />
            <span className="status-label">{connected ? "Connected" : "Reconnecting..."}</span>
          </div>
        </header>

        {/* Messages */}
        <div className="messages-area">
          {loadingHistory ? (
            <div className="loading-msg">Loading messages...</div>
          ) : messages.length === 0 ? (
            <div className="empty-msg">
              <p>🎉 You're the first here!</p>
              <p>Send a message to get started in <strong>#{roomId}</strong></p>
            </div>
          ) : (
            messages.map((msg, i) => {
              if (msg.system) {
                return (
                  <div key={i} className="system-msg">
                    {msg.message_text}
                  </div>
                );
              }
              const isMine = msg.sender_email === user.email;
              return (
                <div key={i} className={`msg-row ${isMine ? "mine" : "theirs"}`}>
                  {!isMine && (
                    <div
                      className="msg-avatar"
                      style={{ background: getColor(msg.sender_email) }}
                    >
                      {getInitial(msg.sender_email)}
                    </div>
                  )}
                  <div className="msg-bubble-wrap">
                    {!isMine && (
                      <span className="msg-sender">{msg.sender_email}</span>
                    )}
                    <div className={`msg-bubble ${isMine ? "bubble-mine" : "bubble-theirs"}`}>
                      {msg.message_text}
                    </div>
                    <span className="msg-time">{formatTime(msg.created_at)}</span>
                  </div>
                </div>
              );
            })
          )}

          {/* Typing Indicator */}
          {typingUsers.length > 0 && (
            <div className="typing-indicator">
              <span className="typing-dots">
                <span /><span /><span />
              </span>
              {typingUsers.join(", ")} {typingUsers.length === 1 ? "is" : "are"} typing
            </div>
          )}

          <div ref={bottomRef} />
        </div>

        {/* Input */}
        <footer className="chat-footer">
          <input
            className="msg-input"
            type="text"
            placeholder={`Message #${roomId}...`}
            value={input}
            onChange={handleInputChange}
            onKeyDown={(e) => e.key === "Enter" && sendMessage()}
            maxLength={500}
          />
          <button
            className="send-btn"
            onClick={sendMessage}
            disabled={!input.trim()}
          >
            Send ↑
          </button>
        </footer>
      </main>
    </div>
  );
}
