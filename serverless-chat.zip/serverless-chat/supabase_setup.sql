-- ============================================================
-- NexChat — Supabase SQL Setup
-- Run this entire file in your Supabase SQL Editor
-- ============================================================

-- 1. CONNECTIONS TABLE
--    Tracks active WebSocket connections per user per room
CREATE TABLE IF NOT EXISTS connections (
  id         uuid        DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id    uuid        REFERENCES auth.users(id) ON DELETE CASCADE,
  socket_id  text        NOT NULL UNIQUE,
  room_id    text        NOT NULL DEFAULT 'general',
  created_at timestamptz DEFAULT now()
);

-- Auto-clean stale connections older than 24 hours
CREATE INDEX IF NOT EXISTS idx_connections_room ON connections(room_id);
CREATE INDEX IF NOT EXISTS idx_connections_socket ON connections(socket_id);


-- 2. MESSAGES TABLE
--    Persists all chat messages with sender info
CREATE TABLE IF NOT EXISTS messages (
  id           uuid        DEFAULT gen_random_uuid() PRIMARY KEY,
  room_id      text        NOT NULL DEFAULT 'general',
  sender_id    uuid        REFERENCES auth.users(id) ON DELETE SET NULL,
  sender_email text        NOT NULL,
  message_text text        NOT NULL CHECK (char_length(message_text) <= 500),
  created_at   timestamptz DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_messages_room_time ON messages(room_id, created_at);


-- 3. ROW LEVEL SECURITY (RLS)
--    Ensures users can only read/write their own data
ALTER TABLE connections ENABLE ROW LEVEL SECURITY;
ALTER TABLE messages    ENABLE ROW LEVEL SECURITY;

-- Connections: allow all authenticated users to read/write
CREATE POLICY "Allow authenticated access to connections"
  ON connections FOR ALL
  USING (auth.role() = 'authenticated');

-- Messages: anyone authenticated can read messages
CREATE POLICY "Allow authenticated users to read messages"
  ON messages FOR SELECT
  USING (auth.role() = 'authenticated');

-- Messages: only the sender can insert their own messages
CREATE POLICY "Allow users to insert their own messages"
  ON messages FOR INSERT
  WITH CHECK (auth.uid() = sender_id);


-- 4. DONE!
--    After running this, go back to your app and start chatting.
SELECT 'NexChat tables created successfully! 🚀' AS status;
