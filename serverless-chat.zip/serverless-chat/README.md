# ⚡ NexChat — Serverless Real-Time Chat App

A production-ready real-time chat application built with:
- **React.js** (Frontend) → deployed on **Vercel** (Free)
- **Node.js + Express + Socket.IO** (Backend) → deployed on **Render** (Free)
- **Supabase** (Database + Auth) → Free tier
- **100% Free. No AWS. No credit card.**

---

## 📁 Project Structure

```
serverless-chat/
├── client/                  ← React frontend (deploy to Vercel)
│   ├── public/index.html
│   └── src/
│       ├── App.jsx          ← Root component + session handling
│       ├── App.css          ← All styles
│       ├── Login.jsx        ← Auth (login + signup)
│       ├── Chat.jsx         ← Main chat UI
│       ├── supabaseClient.js
│       └── index.js
├── server/                  ← Express + Socket.IO backend (deploy to Render)
│   ├── index.js
│   ├── package.json
│   └── .env.example
├── supabase_setup.sql       ← Run this in Supabase SQL Editor
└── README.md
```

---

## 🚀 Setup Guide (Step by Step)

### STEP 1 — Supabase (Database + Auth)

1. Go to https://supabase.com → **New Project** (free)
2. Once created, go to **SQL Editor**
3. Paste the contents of `supabase_setup.sql` and click **Run**
4. Go to **Authentication → Providers** → enable **Email**
5. Go to **Project Settings → API** → copy:
   - `Project URL`  → your `SUPABASE_URL`
   - `anon public` key → your `SUPABASE_ANON_KEY`

---

### STEP 2 — Backend (Render)

1. Create a new GitHub repo, push the `/server` folder to it
2. Go to https://render.com → **New Web Service**
3. Connect your GitHub repo
4. Set:
   - **Build Command:** `npm install`
   - **Start Command:** `node index.js`
5. Add **Environment Variables:**
   ```
   SUPABASE_URL       = your_supabase_project_url
   SUPABASE_ANON_KEY  = your_supabase_anon_key
   PORT               = 4000
   ```
6. Deploy → copy the live URL (e.g. `https://your-app.onrender.com`)

> ⚠️ Render free tier sleeps after 15 min of inactivity. First load may take ~30s.

---

### STEP 3 — Frontend (Vercel)

1. Create a new GitHub repo, push the `/client` folder to it
2. Go to https://vercel.com → **New Project** → import repo
3. Add **Environment Variables:**
   ```
   REACT_APP_SUPABASE_URL      = your_supabase_project_url
   REACT_APP_SUPABASE_ANON_KEY = your_supabase_anon_key
   REACT_APP_BACKEND_URL       = https://your-render-app.onrender.com
   ```
4. Click **Deploy** ✅

---

## 💻 Run Locally

### Backend
```bash
cd server
npm install
cp .env.example .env    # Fill in your Supabase credentials
npm run dev             # Runs on http://localhost:4000
```

### Frontend
```bash
cd client
npm install
cp .env.example .env    # Fill in your credentials + set BACKEND_URL=http://localhost:4000
npm start               # Runs on http://localhost:3000
```

---

## ✨ Features

- 🔐 Email signup/login via Supabase Auth
- 💬 Real-time messaging with Socket.IO WebSockets
- 🏠 Multiple chat rooms (general, tech, random, announcements)
- 📜 Message history loaded on room join
- ✍️ Live typing indicators
- 👋 Join/leave notifications
- 📱 Responsive design (mobile-friendly)
- 🎨 Dark-mode UI with unique color avatars

---

## 🏗️ Architecture

```
[React on Vercel]
      |
      | WebSocket (Socket.IO)
      ↓
[Express on Render]
      |
      ├── Save messages    → [Supabase DB]
      ├── Save connections → [Supabase DB]
      ├── Auth verify      → [Supabase Auth]
      └── Broadcast msg    → [All connected clients]
```

---

## 🗺️ How It Maps to Serverless Concepts

| Serverless Concept   | This Project's Equivalent      |
|---------------------|-------------------------------|
| AWS Lambda           | Socket.IO event handlers       |
| API Gateway          | Express + Socket.IO server     |
| DynamoDB             | Supabase (PostgreSQL)          |
| AWS Cognito          | Supabase Auth                  |
| CloudFront/S3        | Vercel CDN                     |
| Auto-scaling         | Render auto-scaling            |

---

## 📝 License
MIT — Free to use, modify, and deploy.
