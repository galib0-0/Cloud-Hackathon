require("dotenv").config();
const express = require("express");
const http = require("http");
const { Server } = require("socket.io");
const cors = require("cors");
const { createClient } = require("@supabase/supabase-js");

// ── Init ──────────────────────────────────────────────────────────────────────
const app = express();
const server = http.createServer(app);
const supabase = createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_ANON_KEY
);

const io = new Server(server, {
  cors: {
    origin: "*",
    methods: ["GET", "POST"],
  },
});

app.use(cors());
app.use(express.json());

// ── Health Check ──────────────────────────────────────────────────────────────
app.get("/", (req, res) => {
  res.json({ status: "Chat server is running 🚀" });
});

// ── REST: Fetch Message History ───────────────────────────────────────────────
app.get("/messages/:roomId", async (req, res) => {
  try {
    const { roomId } = req.params;
    const { data, error } = await supabase
      .from("messages")
      .select("*")
      .eq("room_id", roomId)
      .order("created_at", { ascending: true })
      .limit(100);

    if (error) throw error;
    res.json(data);
  } catch (err) {
    console.error("Error fetching messages:", err.message);
    res.status(500).json({ error: err.message });
  }
});

// ── REST: Fetch Active Rooms ──────────────────────────────────────────────────
app.get("/rooms", async (req, res) => {
  try {
    const { data, error } = await supabase
      .from("messages")
      .select("room_id")
      .order("created_at", { ascending: false });

    if (error) throw error;

    // Return unique room IDs
    const rooms = [...new Set(data.map((d) => d.room_id))];
    res.json(rooms);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── Socket.IO ─────────────────────────────────────────────────────────────────
io.on("connection", (socket) => {
  console.log(`[CONNECT] Socket ID: ${socket.id}`);

  // ── JOIN ROOM ───────────────────────────────────────────────────────────────
  socket.on("join_room", async ({ roomId, userId, email }) => {
    // Leave previous rooms (except default socket room)
    const prevRooms = [...socket.rooms].filter((r) => r !== socket.id);
    prevRooms.forEach((r) => socket.leave(r));

    socket.join(roomId);
    socket.data = { roomId, userId, email };

    // Persist connection to Supabase
    try {
      // Remove old connection record if any
      await supabase.from("connections").delete().eq("socket_id", socket.id);

      // Insert new connection
      await supabase.from("connections").insert({
        user_id: userId,
        socket_id: socket.id,
        room_id: roomId,
      });
    } catch (err) {
      console.error("Error saving connection:", err.message);
    }

    // Notify room
    socket.to(roomId).emit("user_joined", {
      email,
      message: `${email} joined the room`,
    });

    console.log(`[JOIN] ${email} joined room: ${roomId}`);
  });

  // ── SEND MESSAGE ────────────────────────────────────────────────────────────
  socket.on("send_message", async ({ roomId, userId, email, messageText }) => {
    if (!messageText || !messageText.trim()) return;

    const timestamp = new Date().toISOString();
    const messageData = {
      room_id: roomId,
      sender_id: userId,
      sender_email: email,
      message_text: messageText.trim(),
      created_at: timestamp,
    };

    // Save to Supabase
    try {
      const { error } = await supabase.from("messages").insert(messageData);
      if (error) throw error;
    } catch (err) {
      console.error("Error saving message:", err.message);
      socket.emit("error", { message: "Failed to save message." });
      return;
    }

    // Broadcast to everyone in the room (including sender)
    io.to(roomId).emit("receive_message", messageData);
    console.log(`[MSG] ${email} in ${roomId}: ${messageText}`);
  });

  // ── TYPING INDICATOR ────────────────────────────────────────────────────────
  socket.on("typing", ({ roomId, email, isTyping }) => {
    socket.to(roomId).emit("typing", { email, isTyping });
  });

  // ── DISCONNECT ──────────────────────────────────────────────────────────────
  socket.on("disconnect", async () => {
    const { roomId, email } = socket.data || {};

    try {
      await supabase.from("connections").delete().eq("socket_id", socket.id);
    } catch (err) {
      console.error("Error removing connection:", err.message);
    }

    if (roomId && email) {
      socket.to(roomId).emit("user_left", {
        email,
        message: `${email} left the room`,
      });
    }

    console.log(`[DISCONNECT] ${email || "Unknown"} (${socket.id})`);
  });
});

// ── Start Server ──────────────────────────────────────────────────────────────
const PORT = process.env.PORT || 4000;
server.listen(PORT, () => {
  console.log(`\n🚀 Chat server running on port ${PORT}`);
  console.log(`📡 WebSocket ready`);
  console.log(`🗄️  Supabase connected\n`);
});
